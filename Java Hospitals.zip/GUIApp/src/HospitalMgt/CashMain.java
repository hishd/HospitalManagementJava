package HospitalMgt;
import java.awt.print.PrinterException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class CashMain extends javax.swing.JFrame {

    private static final String uname = "root";
    private static final String pswd = "";
    private static final String constring = "jdbc:mysql://localhost/hospital";
    double billtot = 1000;

    public CashMain() {
        initComponents();
        loaddata();
        jTable1.setDefaultEditor(Object.class, null);
    }
    /*
    public void printbill(String bill, String info)
    {
        try
        {
            FileWriter fw = new FileWriter("bills/"+bill+".txt",true);
            fw.write(info);
            fw.close();
        }
        catch(IOException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }
*/
    private void setfinish()
    {
        try
        {
            String bdate = new SimpleDateFormat("MM/dd/yyyy").format(new java.util.Date());
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(constring,uname,pswd);
            PreparedStatement ps = con.prepareStatement("update prescrip set Done = 1 where pid = '"+txtpid.getText()+"'");
            if(ps.executeUpdate()>0)
                msgbox("Success","Bill generated and ready for printing");
            else
                msgbox("Error","Bille generation completed with errors please recheck");
            
            ps = con.prepareStatement("insert into bill(pid,Name,Date,Amount) values('"+txtpid.getText()+"','"+txtpname.getText()+"','"+bdate+"','"+billtot+"')");
            ps.executeUpdate();
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }
    
    private void msgbox(String cap,String msg)
    {
        JOptionPane.showMessageDialog(this, msg, cap, JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void loaddata()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(constring,uname,pswd);
            PreparedStatement ps = con.prepareStatement("select pid,Name,Medicine,Days,Info from prescrip where Done = 0");
            ResultSet rs = ps.executeQuery();
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtbinfo = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtmed = new javax.swing.JTextField();
        txtup = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtpid = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtpname = new javax.swing.JTextField();
        btnadd = new javax.swing.JButton();
        btngenbill = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtqty = new javax.swing.JTextField();
        printbill = new javax.swing.JButton();
        btnlogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cashier");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("Cashier");

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Prescription Information"));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Bill Information"));

        txtbinfo.setColumns(20);
        txtbinfo.setRows(5);
        jScrollPane2.setViewportView(txtbinfo);

        jLabel2.setText("Medicine");

        jLabel3.setText("Unit Price");

        txtup.setEditable(false);
        txtup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtupActionPerformed(evt);
            }
        });

        jLabel4.setText("Patient ID");

        txtpid.setEditable(false);

        jLabel5.setText("Patient Name");

        txtpname.setEditable(false);

        btnadd.setText("Add");
        btnadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaddActionPerformed(evt);
            }
        });

        btngenbill.setText("Generate Bill");
        btngenbill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngenbillActionPerformed(evt);
            }
        });

        jLabel6.setText("Bill Information");

        jLabel7.setText("Quantity");

        txtqty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtqtyActionPerformed(evt);
            }
        });

        printbill.setText("Print Bill");
        printbill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printbillActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(24, 24, 24)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtpname, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtpid, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel6)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel7))
                                .addGap(46, 46, 46)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtmed, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtup, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(printbill)
                                            .addComponent(txtqty, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addComponent(btnadd))))
                            .addComponent(btngenbill))
                        .addGap(0, 15, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtpid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtpname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtmed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtqty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(btnadd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btngenbill, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(printbill, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        btnlogout.setText("Logout");
        btnlogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addContainerGap(799, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnlogout, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 463, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnlogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtupActionPerformed

    }//GEN-LAST:event_txtupActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        int row = jTable1.getSelectedRow();
        txtpname.setText(jTable1.getValueAt(row, 1).toString());
        txtpid.setText(jTable1.getValueAt(row, 0).toString());
        txtbinfo.setText(null);
        String txt = "------ BILL INFO -------"+"\nPatient No : "+jTable1.getValueAt(row, 0).toString()+"\nPatient Name : "+jTable1.getValueAt(row, 1).toString()+"\nChanell Fee : 1000.00\n"+"\n----MEDICINE INFO----\n";
        txtbinfo.setText(txt);
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void txtqtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtqtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtqtyActionPerformed

    private void btngenbillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngenbillActionPerformed
        
        if(txtpid.getText().length()<1)
            msgbox("Error","Please select a prescription from the table before generating bill");
        else
        {
            txtbinfo.append("\n\nTotal Amount = "+billtot);
            //printbill(txtpid.getText(),txtbinfo.getText());
            try
            {
                String fname = txtpid.getText();
                FileWriter fw = new FileWriter ("bills/"+fname+".txt");
                txtbinfo.write(fw); //Object of JTextArea
                setfinish();
                loaddata();
            }
            catch(IOException ex)
            {
                msgbox("Exception",ex.getMessage());
            }
        }
        
    }//GEN-LAST:event_btngenbillActionPerformed

    private void btnaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaddActionPerformed

        try
        {
            int flagn = 0;
            int flagq = 0;
            int q = 0;
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(constring,uname,pswd);
                        
                if(txtpid.getText().length()<1)
                    msgbox("Error","Please select a prescription from the table before adding medicine");
                else if(txtmed.getText().length()<1)
                    msgbox("Error","Please Enter the Medicine Name");
                else if(txtqty.getText().length()<1)
                    msgbox("Error","Please Enter the Medicine Quantity");
                
                else
                {
                    PreparedStatement ps = con.prepareStatement("select name,qty,price from meds where name = '"+txtmed.getText()+"'");
                    ResultSet rs = ps.executeQuery();
                    if(rs.next())
                    {
                        q = Integer.parseInt(rs.getString("qty"));
                        flagn++;
                    }
                    
                    if(Integer.parseInt(txtqty.getText())<q)
                        flagq++;
                    
                    if(flagn==0)
                    {
                        msgbox("Sorry","Sorry the requested medicine is not availabe please recheck name");
                    }
                    else if(flagq==0)
                    {
                        msgbox("Insufficent Quantity","Sorry maximum available quantity is = '"+String.valueOf(q)+"'");
                    }
                    else
                    {

                        txtup.setText(rs.getString("price"));
                        String med = txtmed.getText();
                        double up = Double.parseDouble(txtup.getText());
                        int qty = Integer.parseInt(txtqty.getText());
                        double tot = up*qty;
                        billtot = billtot + tot;

                        String txt = "\n"+med+"\t"+String.valueOf(tot);
                                                
                        int bal = q - Integer.parseInt(txtqty.getText());
                        ps = con.prepareStatement("update meds set qty = '"+bal+"' where name = '"+txtmed.getText()+"'");
                        ps.executeUpdate();
                        
                        txtbinfo.append(txt);
                        txtmed.setText(null);
                        txtup.setText(null);
                        txtqty.setText(null);
                    }
                      
                }
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }//GEN-LAST:event_btnaddActionPerformed

    private void printbillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printbillActionPerformed

        try
        {
            if(txtpid.getText().length()<1)
                 msgbox("Error","Please select a prescription from the table before printing bill");
            else
                txtbinfo.print();
        }
        catch(PrinterException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        
    }//GEN-LAST:event_printbillActionPerformed

    private void btnlogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlogoutActionPerformed
        this.dispose();
        new Login().show();
    }//GEN-LAST:event_btnlogoutActionPerformed


    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CashMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnadd;
    private javax.swing.JButton btngenbill;
    private javax.swing.JButton btnlogout;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton printbill;
    private javax.swing.JTextArea txtbinfo;
    private javax.swing.JTextField txtmed;
    private javax.swing.JTextField txtpid;
    private javax.swing.JTextField txtpname;
    private javax.swing.JTextField txtqty;
    private javax.swing.JTextField txtup;
    // End of variables declaration//GEN-END:variables
}
