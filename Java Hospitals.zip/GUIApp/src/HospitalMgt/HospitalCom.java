package HospitalMgt;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

import java.net.*;
import java.io.*;

public class HospitalCom {
    
    public static void sendsms(String uname,String pwd,String no,String msg)
    {
        try {
            // Construct data
            String data = "";
            
            data += "username=" + URLEncoder.encode(uname, "ISO-8859-1");
            data += "&password=" + URLEncoder.encode(pwd, "ISO-8859-1");
            data += "&message=" + URLEncoder.encode(msg, "ISO-8859-1");
            data += "&want_report=1";
            data += "&msisdn=+"+no;

            // Send data
            // Please see the FAQ regarding HTTPS (port 443) and HTTP (port 80/5567)
            URL url = new URL("https://bulksms.vsms.net/eapi/submission/send_sms/2/2.0");

            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();

            // Get the response
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = rd.readLine()) != null) {
                // Print the response output...
                System.out.println(line);
            }
            wr.close();
            rd.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void sendemail(String rec,String sub,String msg)
    {
        final String username = "YOUR_EMAIL";
        final String password = "YOUR_PASSWORD";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
          new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                }
          });

        try {

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress("hisharadilshan2@gmail.com"));
                message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(rec));
                message.setSubject(sub);
                message.setText(msg);

                Transport.send(message);

                JOptionPane.showMessageDialog(null,"Email Sent Successfully");

        } catch (MessagingException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
}
