package HospitalMgt;
import java.sql.*;
import javax.swing.*;
import java.io.*;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Login extends javax.swing.JFrame {
    
    private static final String uname = "root";
    private static final String pswd = "";
    private static final String constring = "jdbc:mysql://localhost/hospital";

    public Login() {
        initComponents();
    }
    
    public void writelog(String type, String uname)
    {
        try
        {
            String time = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
            FileWriter fw = new FileWriter("Userlog.txt",true);
            fw.write(type+"\t"+uname+"\t"+time+"\r\n");
            fw.close();
        }
        catch(IOException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }
    
    private void msgbox(String cap, String msg){
   JOptionPane.showMessageDialog(this,msg, cap,JOptionPane.ERROR_MESSAGE);
}
    public void doclogin()
    {
        try
        {
            if(txtuname.getText().length()<1)
                msgbox("Error","Please enter the username");
            else if(txtpwd.getText().length()<1)
                msgbox("Error","Please enter the password");
            else
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(constring,uname,pswd);
                PreparedStatement ps = con.prepareStatement("select * from doctors where uname = '"+txtuname.getText()+"' and pwd = '"+txtpwd.getText()+"'");
                ResultSet rs = ps.executeQuery();
            
                if(rs.next())
                {
                    writelog("Doctor",txtuname.getText());
                    DoctorMain dm = new DoctorMain();
                    dm.setdata(txtuname.getText(),rs.getString("Name"));
                    dm.show();
                    this.dispose();
                }
                else
                {
                    msgbox("Invalid Login","Please Recheck username and password");
                }
            }
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtuname = new javax.swing.JTextField();
        btnlogin = new javax.swing.JButton();
        txtpwd = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        cmbutype = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Login");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Username");
        jLabel2.setMaximumSize(new java.awt.Dimension(60, 20));
        jLabel2.setMinimumSize(new java.awt.Dimension(60, 20));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Password");
        jLabel3.setMaximumSize(new java.awt.Dimension(60, 20));
        jLabel3.setMinimumSize(new java.awt.Dimension(60, 20));

        btnlogin.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnlogin.setText("Login");
        btnlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnloginActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("User Type");
        jLabel4.setMaximumSize(new java.awt.Dimension(60, 20));
        jLabel4.setMinimumSize(new java.awt.Dimension(60, 20));

        cmbutype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrator", "Receptionist", "Cashier", "Doctor", "Pharmacist" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 230, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnlogin, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtuname)
                    .addComponent(txtpwd, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                    .addComponent(cmbutype, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbutype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtuname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtpwd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnlogin, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        txtuname.getAccessibleContext().setAccessibleName("txtuname");

        getAccessibleContext().setAccessibleName("lblLogin");
        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnloginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnloginActionPerformed
        
        Connection con = null;
        PreparedStatement ps;
        String type = "";
        if(cmbutype.getSelectedIndex() == 0)
        {
            type = "admin";
        }
        else if(cmbutype.getSelectedIndex() == 1)
        {
            type = "recep";
        }
        else if(cmbutype.getSelectedIndex() == 2)
        {
            type = "cash";
        }
        else if(cmbutype.getSelectedIndex()==3)
        {
            doclogin();
            type = "doctor";
        }
        else if(cmbutype.getSelectedIndex()==4)
        {
            type = "pharmacist";
        }
         
        if(txtuname.getText().length()<1)
            msgbox("Error","Please enter the username");
        else if(txtpwd.getText().length()<1)
            msgbox("Error","Please enter the password");
        else
            if(!type.equals("doctor"))
            {
                    try
                    {
                        Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection(constring,uname,pswd);
                        ps = con.prepareStatement("select * from user where uid = '"+txtuname.getText()+"' and pwd = '"+txtpwd.getText()+"' and type = '"+type+"'");
                        ResultSet rs = ps.executeQuery();

                        if(rs.next())
                        {
                            if(type == "admin")
                            {
                                writelog("Admin",txtuname.getText());
                                new AdminMain().setVisible(true);
                                this.dispose();
                            }
                            else if(type == "recep")
                            {
                                writelog("Receptionist",txtuname.getText());
                                new RecepMain().setVisible(true);
                                this.dispose();
                            }
                            else if(type == "cash")
                            {
                                writelog("Cashier",txtuname.getText());
                                new CashMain().setVisible(true);
                                this.dispose();
                            }
                            else if(type == "pharmacist")
                            {
                                writelog("Pharmacist",txtuname.getText());
                                new PharMain().setVisible(true);
                                this.dispose();
                            }
                        }
                        else
                        {
                            msgbox("Login Faild","Check username and password");
                        }
                    }
                    catch(SQLException ex)
                    {
                        //System.err.println(ex);
                        msgbox("Exception",ex.getMessage());
                    }
                    catch(ClassNotFoundException ex)
                    {
                        //System.err.println(ex);
                        msgbox("Exception",ex.getMessage());
                    }
            }
    }//GEN-LAST:event_btnloginActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnlogin;
    private javax.swing.JComboBox<String> cmbutype;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPasswordField txtpwd;
    private javax.swing.JTextField txtuname;
    // End of variables declaration//GEN-END:variables
}
