
package HospitalMgt;
import java.sql.*;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class Adm_doctor extends javax.swing.JFrame {

    private static final String uname = "root";
    private static final String pswd = "";
    private static final String constring = "jdbc:mysql://localhost/hospital";
    Connection con = null;
    static int flag = 0;
    
    public void msgbox(String cap, String msg)
    {
        JOptionPane.showMessageDialog(this,msg,cap,JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void gettablevalues()
    {
        int row = jTable1.getSelectedRow();
        txtremdid.setText(jTable1.getValueAt(row, 0).toString());
        txtdname1.setText(jTable1.getValueAt(row, 1).toString());
        txtduname1.setText(jTable1.getValueAt(row, 3).toString());
        txtdpwd1.setText(jTable1.getValueAt(row, 4).toString());
    }
    
    public void loaddata()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(constring,uname,pswd);
            PreparedStatement ps = con.prepareStatement("select * from doctors");
            ResultSet rs = ps.executeQuery();
            jTable1.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }

    public Adm_doctor() {
        initComponents();
        loaddata();
        jTable1.setDefaultEditor(Object.class, null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        tabbedPane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtduname = new javax.swing.JTextField();
        txtdname = new javax.swing.JTextField();
        txtdpwd = new javax.swing.JTextField();
        cmbspec = new javax.swing.JComboBox<>();
        btnreg = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtdname1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cmbspec1 = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        txtduname1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtdpwd1 = new javax.swing.JTextField();
        btnupd = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtremdid = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        cmbremdid = new javax.swing.JComboBox<>();
        btnrem = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Doctors");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setText("Doctors");

        tabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabbedPaneMouseClicked(evt);
            }
        });

        jLabel2.setText("Doctor Name");

        jLabel3.setText("Speciality");

        jLabel4.setText("Username");

        jLabel5.setText("Password");

        cmbspec.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cardiologist", "Dermatologist", "Neurologist", "Physiatrist", "Radiologist", "Surgeon", "Urologist" }));

        btnreg.setText("Register Doctor");
        btnreg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnregActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtdpwd, javax.swing.GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtdname)
                            .addComponent(txtduname)
                            .addComponent(cmbspec, 0, 153, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(138, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnreg)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtdname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cmbspec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtduname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtdpwd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addComponent(btnreg, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabbedPane.addTab("Add Doctor", jPanel1);

        jLabel6.setText("Doctor Name");

        jLabel7.setText("Speciality");

        cmbspec1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cardiologist", "Dermatologist", "Neurologist", "Physiatrist", "Radiologist", "Surgeon", "Urologist" }));

        jLabel8.setText("Username");

        jLabel9.setText("Password");

        btnupd.setText("Update Doctor");
        btnupd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdActionPerformed(evt);
            }
        });

        jLabel10.setText("Doctor ID");

        txtremdid.setEditable(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnupd)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel7)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtdpwd1, javax.swing.GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtremdid, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtdname1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtduname1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbspec1, javax.swing.GroupLayout.Alignment.LEADING, 0, 153, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(138, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtremdid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtdname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cmbspec1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtduname1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtdpwd1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(btnupd, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        tabbedPane.addTab("Update Doctor", jPanel2);

        jLabel11.setText("Doctor ID");

        btnrem.setText("Remove Doctor");
        btnrem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnremActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnrem)
                .addGap(39, 39, 39))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(cmbremdid, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(168, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel11)
                    .addContainerGap(325, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(cmbremdid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(btnrem, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(156, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(29, 29, 29)
                    .addComponent(jLabel11)
                    .addContainerGap(253, Short.MAX_VALUE)))
        );

        tabbedPane.addTab("Remove Doctor", jPanel3);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jScrollPane2.setViewportView(jScrollPane1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(tabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnregActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregActionPerformed
        
        try
        {
            if(txtdname.getText().length()<1)
                msgbox("Error","Please Enter the doctor name");
            else if(!txtdname.getText().matches("^[a-zA-Z]+$"))
                msgbox("Error","Please Enter a valid name");
            else if(txtduname.getText().length()<1)
                msgbox("Error","Please Enter a username for the doctor");
            else if(txtdpwd.getText().length()<1)
                msgbox("Error","Please Enter a password for the doctor");
            else
            {
            
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(constring,uname,pswd);
                PreparedStatement ps = con.prepareStatement("insert into doctors(Name,Spe,uname,pwd) values('"+txtdname.getText()+"','"+cmbspec.getSelectedItem().toString()+"','"+txtduname.getText()+"','"+txtdpwd.getText()+"')");
                if(ps.executeUpdate()>0)
                    msgbox("Success","Registration Successful");
                loaddata();
                txtdname.setText(null);
                txtduname.setText(null);
                txtdpwd.setText(null);
            }
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }//GEN-LAST:event_btnregActionPerformed

    private void tabbedPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabbedPaneMouseClicked
        
        //cmbdid.removeAllItems();
        cmbremdid.removeAllItems();
        
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(constring,uname,pswd);
                PreparedStatement ps = con.prepareStatement("select did from doctors");
                ResultSet rs = ps.executeQuery();

                while(rs.next())
                {
                    //cmbdid.addItem(rs.getString("did"));
                    cmbremdid.addItem(rs.getString("did"));
                }
                
                flag++;
            }
            catch(ClassNotFoundException ex)
            {
                msgbox("Exception",ex.getMessage());
            }
            catch(SQLException ex)
            {
                msgbox("Exception",ex.getMessage());
            }
        
    }//GEN-LAST:event_tabbedPaneMouseClicked

    private void btnupdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdActionPerformed
        try
        {
            if(txtremdid.getText().length()<1)
                msgbox("Error","Please Select a doctor from the table");
            else if(txtdname1.getText().length()<1)
                msgbox("Error","Please Enter the doctor name");
            else if(!txtdname1.getText().matches("^[a-zA-Z]+$"))
                msgbox("Error","Please Enter a valid name");
            else if(txtduname1.getText().length()<1)
                msgbox("Error","Please Enter a username for the doctor");
            else if(txtdpwd1.getText().length()<1)
                msgbox("Error","Please Enter a password for the doctor");
            else
            {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(constring,uname,pswd);
                PreparedStatement ps = con.prepareStatement("update doctors set Name = '"+txtdname1.getText()+"', Spe = '"+cmbspec1.getSelectedItem().toString()+"', uname = '"+txtduname1.getText()+"', pwd = '"+txtdpwd1.getText()+"' where did = '"+txtremdid.getText()+"'");
                if(ps.executeUpdate()>0)
                    msgbox("Success","Successfully Updated");
                loaddata();
                txtremdid.setText(null);
                txtdname1.setText(null);
                txtduname1.setText(null);
                txtdpwd1.setText(null);
                loaddata();
            }
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }//GEN-LAST:event_btnupdActionPerformed

    private void btnremActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnremActionPerformed
        
        try
        {
            if(cmbremdid.getSelectedIndex()<0)
                msgbox("Error","Please select a doctor id from the dropdown menu");
            else
            {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(constring,uname,pswd);
                PreparedStatement ps = con.prepareStatement("delete from doctors where did = '"+cmbremdid.getSelectedItem().toString()+"'");
                if(ps.executeUpdate()>0)
                    msgbox("Success","Successfully Removed");
                loaddata();
            }
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
    }//GEN-LAST:event_btnremActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        gettablevalues();
    }//GEN-LAST:event_jTable1MouseClicked


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Adm_doctor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnreg;
    private javax.swing.JButton btnrem;
    private javax.swing.JButton btnupd;
    private javax.swing.JComboBox<String> cmbremdid;
    private javax.swing.JComboBox<String> cmbspec;
    private javax.swing.JComboBox<String> cmbspec1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTextField txtdname;
    private javax.swing.JTextField txtdname1;
    private javax.swing.JTextField txtdpwd;
    private javax.swing.JTextField txtdpwd1;
    private javax.swing.JTextField txtduname;
    private javax.swing.JTextField txtduname1;
    private javax.swing.JTextField txtremdid;
    // End of variables declaration//GEN-END:variables
}
