package HospitalMgt;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

public class Loading extends javax.swing.JFrame {
    
        Timer t;
        ActionListener al;
        int i = 0;
        
        public void disposeob()
        {
            //this.hide();
            this.dispose();
            new Login().setVisible(true);
        }

    public Loading() {
        initComponents();
        
        al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(jProgressBar1.getValue()<100)
                {
                    i+=5;
                    jProgressBar1.setValue(jProgressBar1.getValue()+5);
                }
                    
                if(jProgressBar1.getValue()==100)
                {
                    t.stop();
                    disposeob();
                }
            }
        };
        t = new Timer(200,al);
        t.start();
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Hospital Management System");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/HospitalMgt/hospital1234.png"))); // NOI18N

        jProgressBar1.setForeground(new java.awt.Color(255, 0, 51));
        jProgressBar1.setOpaque(true);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

 
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Loading().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JProgressBar jProgressBar1;
    // End of variables declaration//GEN-END:variables
}
