
package HospitalMgt;
import java.sql.*;
import java.text.DateFormat;
import javax.swing.JOptionPane;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.proteanit.sql.DbUtils;

public class RecepMain extends javax.swing.JFrame {
    
    private String constring = "jdbc:mysql://localhost/hospital";
    private String uname = "root";
    private String pswd = "";
    
    private Pattern regexPattern;
    private Matcher regMatcher;

    
    Connection con;

    public RecepMain() {
        initComponents();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        calapp.setMinSelectableDate(date);
        jTable1.setDefaultEditor(Object.class, null);
    }
    
    public void msgbox(String cap, String msg)
    {
        JOptionPane.showMessageDialog(this,msg,cap,JOptionPane.INFORMATION_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtpname = new javax.swing.JTextField();
        txtpconno = new javax.swing.JTextField();
        cmbpbgrp = new javax.swing.JComboBox<>();
        txtpage = new javax.swing.JTextField();
        txtpemail = new javax.swing.JTextField();
        rbtnmale = new javax.swing.JRadioButton();
        rbtnfemale = new javax.swing.JRadioButton();
        cmbdcat = new javax.swing.JComboBox<>();
        cmbdoc = new javax.swing.JComboBox<>();
        btnregister = new javax.swing.JButton();
        calapp = new com.toedter.calendar.JDateChooser();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtpadd = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        txtpnic = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        chksms = new javax.swing.JCheckBox();
        chkemail = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        rbtndspe = new javax.swing.JRadioButton();
        rbtndname = new javax.swing.JRadioButton();
        cmbdspe = new javax.swing.JComboBox<>();
        txtdname = new javax.swing.JTextField();
        btnsearchd = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        rbtnappdate = new javax.swing.JRadioButton();
        rbtnpname = new javax.swing.JRadioButton();
        txtpsname = new javax.swing.JTextField();
        btnsearchp = new javax.swing.JButton();
        calpapp = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnlogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Receptionist");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("Receptionist");

        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jLabel2.setText("Patient Name");

        jLabel3.setText("Patient Contact No.");

        jLabel4.setText("Patient Address");

        jLabel5.setText("Blood Group");

        jLabel6.setText("Age");

        jLabel7.setText("Email");

        jLabel8.setText("Sex");

        jLabel9.setText("Appoinment Date");

        jLabel10.setText("Doctor Category");
        jLabel10.setToolTipText("");

        jLabel11.setText("Doctor");
        jLabel11.setToolTipText("");

        cmbpbgrp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A Group", "B Group", "O Group", "AB Group" }));

        buttonGroup1.add(rbtnmale);
        rbtnmale.setSelected(true);
        rbtnmale.setText("Male");

        buttonGroup1.add(rbtnfemale);
        rbtnfemale.setText("Female");

        cmbdcat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cardiologist", "Dermatologist", "Neurologist", "Physiatrist", "Radiologist", "Surgeon", "Urologist" }));
        cmbdcat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbdcatMouseClicked(evt);
            }
        });

        cmbdoc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbdocMouseClicked(evt);
            }
        });

        btnregister.setText("Register");
        btnregister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnregisterActionPerformed(evt);
            }
        });

        txtpadd.setColumns(20);
        txtpadd.setRows(5);
        jScrollPane2.setViewportView(txtpadd);

        jLabel13.setText("NIC No");

        jLabel12.setText("Notify Info");

        chksms.setText("SMS");

        chkemail.setText("Email");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnregister, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel4)
                                                    .addGap(37, 37, 37))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel5)
                                                    .addGap(55, 55, 55)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel6)
                                                .addGap(94, 94, 94)))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel7)
                                                .addComponent(jLabel13))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3))
                                        .addGap(18, 18, 18)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtpnic, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtpconno, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                                    .addComponent(cmbpbgrp, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtpage, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtpemail, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2)
                                    .addComponent(txtpname, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(chksms, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(chkemail))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11))
                                .addGap(30, 30, 30)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(calapp, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(rbtnmale)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(rbtnfemale))
                                    .addComponent(cmbdcat, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cmbdoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 54, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtpname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtpconno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel4)
                        .addGap(44, 44, 44))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cmbpbgrp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtpage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtpemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtpnic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(rbtnmale)
                    .addComponent(rbtnfemale))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9)
                    .addComponent(calapp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cmbdcat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cmbdoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(chksms)
                    .addComponent(chkemail))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(btnregister, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Register Patient", jPanel1);

        buttonGroup2.add(rbtndspe);
        rbtndspe.setSelected(true);
        rbtndspe.setText("Speciality");

        buttonGroup2.add(rbtndname);
        rbtndname.setText("Name");

        cmbdspe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cardiologist", "Dermatologist", "Neurologist", "Physiatrist", "Radiologist", "Surgeon", "Urologist" }));

        btnsearchd.setText("Search");
        btnsearchd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rbtndspe)
                    .addComponent(rbtndname))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cmbdspe, 0, 152, Short.MAX_VALUE)
                    .addComponent(txtdname))
                .addGap(0, 131, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnsearchd, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtndspe)
                    .addComponent(cmbdspe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtndname)
                    .addComponent(txtdname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(61, 61, 61)
                .addComponent(btnsearchd, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(404, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("View Doctors", jPanel2);

        buttonGroup3.add(rbtnappdate);
        rbtnappdate.setSelected(true);
        rbtnappdate.setText("Appoinment Date");

        buttonGroup3.add(rbtnpname);
        rbtnpname.setText("Name");

        btnsearchp.setText("Search");
        btnsearchp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchpActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnsearchp, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(rbtnappdate)
                                .addGap(18, 18, 18)
                                .addComponent(calpapp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(rbtnpname)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(127, 127, 127)
                                .addComponent(txtpsname, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(106, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rbtnappdate)
                    .addComponent(calpapp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtnpname)
                    .addComponent(txtpsname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(61, 61, 61)
                .addComponent(btnsearchp, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(405, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Patients", jPanel3);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        btnlogout.setText("Logout");
        btnlogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 567, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btnlogout, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jTabbedPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnlogout, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnregisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnregisterActionPerformed
        
        String sex = "";
        regexPattern = Pattern.compile("^[(a-zA-Z-0-9-\\_\\+\\.)]+@[(a-z-A-z)]+\\.[(a-zA-z)]{2,3}$");
        regMatcher   = regexPattern.matcher(txtpemail.getText());
        
        if(rbtnmale.isSelected())
            sex = "male";
        else
            sex = "female";
        
        if(txtpname.getText().length()<1)
            msgbox("Error","Please enter the patient name");
        else if(!txtpname.getText().matches("^[a-zA-Z]+$"))
            msgbox("Error","Please enter a valid patient name");
        else if(txtpconno.getText().length()!=11)
            msgbox("Error","Please enter a contact no with 94 at the begining");
        else if(!txtpconno.getText().matches("^[0-9]+$"))
            msgbox("Error","Please enter a valid contact no");
        else if(txtpadd.getText().length()<1)
            msgbox("Error","Please enter the patient address");
        else if(txtpage.getText().length()<1)
            msgbox("Error","Please enter the patient age");
        else if(!txtpage.getText().matches("^[0-9]+$"))
            msgbox("Error","Please enter a valid patient age");
        else if(!regMatcher.matches())
            msgbox("Error","Please enter a valid email address");
        else if(txtpnic.getText().length()!=10 || (!txtpnic.getText().substring(9).equals("v")&& !txtpnic.getText().substring(9).equals("V")))
            msgbox("Error","Please enter a valid NIC");
        else if(calapp.getDate()==null)
            msgbox("Error","Please select a appoinment date");
        else if(cmbdoc.getSelectedIndex()<0)
            msgbox("Error","Please select a doctor");
        else 
        {
            try
            {

                SimpleDateFormat dcn = new SimpleDateFormat("yyyy-MM-dd");
                String appdate = dcn.format(calapp.getDate());


                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(constring,uname,pswd);
                PreparedStatement ps = con.prepareStatement("insert into patient(Name,Contact,Address,Blood,Age,NIC,Sex,AppDate,DocSpec,Doc) values('"+txtpname.getText()+"','"+txtpconno.getText()+"','"+txtpadd.getText()+"','"+cmbpbgrp.getSelectedItem().toString()+"','"+txtpage.getText()+"','"+txtpnic.getText()+"','"+sex+"','"+appdate+"','"+cmbdcat.getSelectedItem().toString()+"','"+cmbdoc.getSelectedItem().toString()+"')");
                int s = ps.executeUpdate();

                if(s>0)
                    msgbox("Success","Patient Registered");
                else
                    msgbox("Failed","Patient Registration faild");

                String msg = "Booking Successful\n"+"Name : "+txtpname.getText()+"\nDoctor : "+cmbdoc.getSelectedItem().toString()+"\nThank you";

                if(chksms.isSelected())
                    HospitalCom.sendsms("hishara","idmcc3wattala",txtpconno.getText(),msg);
                if(chkemail.isSelected())
                    HospitalCom.sendemail(txtpemail.getText(),"Appoinment", msg);

            }
            catch(ClassNotFoundException ex)
            {
                msgbox("Exception",ex.getMessage());
            }
            catch(SQLException ex)
            {
                msgbox("Exception",ex.getMessage());
            }
        }
        
        
    }//GEN-LAST:event_btnregisterActionPerformed

    private void cmbdocMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbdocMouseClicked
        
        try
        {
            cmbdoc.removeAllItems();
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(constring,uname,pswd);
            PreparedStatement ps = con.prepareStatement("select Name from doctors where spe = '"+cmbdcat.getSelectedItem().toString()+"'");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next())
                cmbdoc.addItem(rs.getString("Name"));
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
                
        
    }//GEN-LAST:event_cmbdocMouseClicked

    private void cmbdcatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbdcatMouseClicked
        cmbdoc.removeAllItems();
    }//GEN-LAST:event_cmbdcatMouseClicked

    private void btnsearchdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchdActionPerformed
        
        try{
            if(rbtndspe.isSelected())
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection(constring,uname,pswd);
                    PreparedStatement ps = con.prepareStatement("select Name,Spe from doctors where Spe = '"+cmbdspe.getSelectedItem().toString()+"' ");
                    ResultSet rs = ps.executeQuery();
                    jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                    
                }
                else if(rbtndname.isSelected())
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    con = DriverManager.getConnection(constring,uname,pswd);
                    PreparedStatement ps = con.prepareStatement("select Name,Spe from doctors where Name like '%"+txtdname.getText()+"%' ");
                    ResultSet rs = ps.executeQuery();
                    jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                }
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
                        
    }//GEN-LAST:event_btnsearchdActionPerformed

    private void btnsearchpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchpActionPerformed
        
                try
        {
                        
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(constring,uname,pswd);
            
            if(rbtnappdate.isSelected())
            {
                if(calpapp.getDate()==null)
                msgbox("Error","Please select a date first");
                else
                {
                    SimpleDateFormat dcn = new SimpleDateFormat("yyyy-MM-dd");
                    String appdate = dcn.format(calpapp.getDate());
                    PreparedStatement ps = con.prepareStatement("select * from patient where AppDate like '%"+appdate+"%'");
                    ResultSet rs = ps.executeQuery();
                    jTable1.setModel(DbUtils.resultSetToTableModel(rs));
                }
            }
            else if(rbtnpname.isSelected())
            {
                PreparedStatement ps = con.prepareStatement("select * from patient where Name like '%"+txtpsname.getText()+"%'");
                ResultSet rs = ps.executeQuery();
                jTable1.setModel(DbUtils.resultSetToTableModel(rs));
            }
            
        }
        catch(ClassNotFoundException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        catch(SQLException ex)
        {
            msgbox("Exception",ex.getMessage());
        }
        
    }//GEN-LAST:event_btnsearchpActionPerformed

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
        
    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void btnlogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlogoutActionPerformed
        this.dispose();
        new Login().show();
    }//GEN-LAST:event_btnlogoutActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RecepMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnlogout;
    private javax.swing.JButton btnregister;
    private javax.swing.JButton btnsearchd;
    private javax.swing.JButton btnsearchp;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private com.toedter.calendar.JDateChooser calapp;
    private com.toedter.calendar.JDateChooser calpapp;
    private javax.swing.JCheckBox chkemail;
    private javax.swing.JCheckBox chksms;
    private javax.swing.JComboBox<String> cmbdcat;
    private javax.swing.JComboBox<String> cmbdoc;
    private javax.swing.JComboBox<String> cmbdspe;
    private javax.swing.JComboBox<String> cmbpbgrp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JRadioButton rbtnappdate;
    private javax.swing.JRadioButton rbtndname;
    private javax.swing.JRadioButton rbtndspe;
    private javax.swing.JRadioButton rbtnfemale;
    private javax.swing.JRadioButton rbtnmale;
    private javax.swing.JRadioButton rbtnpname;
    private javax.swing.JTextField txtdname;
    private javax.swing.JTextArea txtpadd;
    private javax.swing.JTextField txtpage;
    private javax.swing.JTextField txtpconno;
    private javax.swing.JTextField txtpemail;
    private javax.swing.JTextField txtpname;
    private javax.swing.JTextField txtpnic;
    private javax.swing.JTextField txtpsname;
    // End of variables declaration//GEN-END:variables
}
